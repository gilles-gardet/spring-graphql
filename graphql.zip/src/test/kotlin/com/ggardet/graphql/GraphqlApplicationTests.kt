package com.ggardet.graphql

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GraphqlApplicationTests {

	@Test
	fun contextLoads() {
	}

}
